<Page>
  <Navbar title="FAQ" backLink="Back" />
  <BlockTitle medium>Distanziamento?</BlockTitle>
  <Block strong>
    <Row>
      <Col width="40">
        <img src="static/icons/covid_misc.png" width="100" alt="covid_temp">
      </Col>
      <Col width="60">
        Mantieni sempre la distanza di 1 metro,<strong> evita gli assembramenti</strong> (soprattutto in entrata-uscita, durante gli intervalli e gli spostamenti da e per la classe)<strong> e il contatto fisico</strong> con i compagni
      </Col>
    </Row>
  </Block>

</Page>
<script>
  import { Page, Navbar, Block, BlockTitle, Row, Col } from 'framework7-svelte';
</script>