<Page name="faq1">
  <Navbar title="FAQ" backLink="Back" />
  <BlockTitle medium>Nel caso avessi più di 37.5 C?</BlockTitle>
  <Block strong>
    <img src="static/icons/covid_temp.png" width="100" alt="covid_temp">
    <strong>Se hai più di 37,5° oppure</strong> sintomi di infezione respiratorie acute (febbre, tosse, difficoltà respiratorie, mancanza di olfatto e di gusto…) parlane subito con i genitori e <strong>NON venire a scuola</strong>  
  </Block>
</Page>

<script>
  import { 
    Page, 
    Navbar, 
    BlockTitle, 
    Block
  } from 'framework7-svelte';
</script>