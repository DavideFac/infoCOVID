<Page>
  <Navbar title="FAQ" backLink="Back" />
  <BlockTitle medium>Ci sono altre indicazioni?</BlockTitle>
  <Block strong>
    <Row>
      <Col width="40">
        <img src="static/icons/covid_misc.png" width="100" alt="covid_temp">
      </Col>
      <Col width="60">
        Segui le indicazioni degli insegnanti e rispetta la segnaletica;
      </Col>
    </Row>
  </Block>

</Page>
<script>
  import { Page, Navbar, Block, BlockTitle, Row, Col } from 'framework7-svelte';
</script>