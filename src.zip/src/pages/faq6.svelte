<Page>
  <Navbar title="FAQ" backLink="Back" />
  <BlockTitle medium>Comportamento in pubblico?</BlockTitle>
  <Block strong>
    <Row>
      <Col width="40">
        <img src="static/icons/covid_outside.png" width="100" alt="covid_temp">
      </Col>
      <Col width="60">
       <strong>Sii attento e prudente anche fuori della scuola</strong>: sui mezzi di trasporto e nei locali pubblici, quando fai attività sportiva e sei in compagnia degli amici, in tutte le attività extrascolastiche. Gli effetti di ciò che farai possono risultare gravi per te, per la tua famiglia e i nonni, per i tuoi compagni di scuola

      </Col>
    </Row>
  </Block>

</Page>
<script>
  import { Page, Navbar, Block, BlockTitle, Row, Col } from 'framework7-svelte';
</script>