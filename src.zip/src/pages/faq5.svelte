<Page>
  <Navbar title="FAQ" backLink="Back" />
  <BlockTitle medium>Quando e come lavarsi le mani?</BlockTitle>
  <Block strong>
    <Row>
      <Col width="40">
        <img src="static/icons/covid_hands.png" width="100" alt="covid_temp">
      </Col>
      <Col width="60">
        <strong>Lava frequentemente le mani</strong> o usa gli appositi dispenser per tenerle pulite; evita di toccarti il viso e la mascherina
      </Col>
    </Row>
  </Block>

</Page>
<script>
  import { Page, Navbar, Block, BlockTitle, Row, Col } from 'framework7-svelte';
</script>