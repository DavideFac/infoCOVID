<Page>
  <Navbar title="FAQ" backLink="Back" />
  <BlockTitle medium>Come indossare la mascherina?</BlockTitle>
  <Block strong>
    <Row>
      <Col width="40">
        <img src="static/icons/covid_mask.png" width="100" alt="covid_temp">
      </Col>
      <Col width="60">
        <strong>Quando sei a scuola</strong> e NON è garantito il distanziamento minimo di 1 metro o durante ogni spostamento dall’aula, <strong>indossa la mascherina chirurgica</strong>, per la protezione del naso e della bocca
      </Col>
    </Row>
  </Block>
</Page>
<script>
  import { Page, Navbar, Block, BlockTitle, Row, Col } from 'framework7-svelte';
</script>