<Page>
  <Navbar title="FAQ" backLink="Back" />
  <BlockTitle medium>Come ci proteggiamo?</BlockTitle>
  <Block strong>
    <Row>
      <Col width="40">
        <img src="static/icons/covid_dotazioni.png" width="100" alt="covid_temp">
      </Col>
      <Col width="60">
       Ti chiediamo di <strong>venire a scuola con le seguenti dotazioni di tua responsabilità</strong>: la mascherina, un flacone di gel igienizzante, la sacca (da lavare almeno ogni 3 giorni), i guanti in lattice per i laboratori
      </Col>
    </Row>
  </Block>

</Page>
<script>
  import { Page, Navbar, Block, BlockTitle, Row, Col } from 'framework7-svelte';
</script>